﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Northwind1.Models
{
    public class Products
    {
        //private data
        private int productID = -1;
        private string productName = "n/a";
        private int supplier = -1;
        private int category = -1;
        private string quantityperunit = "n/a";
        private double unitprice = -1;
        private int unitsinstock = -1;
        private int  unitsonorder = -1;
        private int reorderlevel = -1;
        private bool discontinued = false;
        private static int numberofproducts = 0;
        //public getters and setters
        public int ProductID
        {
            get
            {
                return this.productID;
            }

            set
            {
                this.productID = value;
            }
        }


        public string ProductName
        {
            get
            {
                return this.productName;
            }

            set
            {
                this.productName = value;
            }
        }


        public int Supplier
        {

            get
            {
                return this.supplier;
            }

            set
            {
                this.supplier= value;
            }
        }


        public int Category
        {
            get
            {
                return this.category;
            }

            set
            {
                this.category = value;
            }
        }


        public string QuantityPerUnit
        {
            get
            {
                return this.quantityperunit;
            }

            set
            {
                this.quantityperunit = value;
            }
        }


        public double Unitprice
        {
            get
            {
                return this.unitprice;
            }

            set
            {
                this.unitprice = value;
            }
        }


        public int  Unitsinstock
        {
            get
            {
                return this.unitsinstock;
            }

            set
            {
                this.unitsinstock = value;
            }
        }


        public int  Unitsonorder
        {
            get
            {
                return this.unitsonorder;
            }

            set
            {
                this.unitsonorder = value;
            }
        }


        public int Reorderlevel
        {
            get
            {
                return this.reorderlevel;
            }

            set 
            {
                this.reorderlevel = value;
            }
        }


        public bool Discontinued
        {
            get
            {
                return this.discontinued;
            }

            set
            {
                this.discontinued = value;
            }
        }
        //Constructors and chained constructors
        public Products()
        {
            numberofproducts = numberofproducts + 1;
        }

        public Products(int aProductID, string aProductName, int aSupplier, int aCategory, string aQuantityperunit, double aUnitprice, int aUnitsinstock, int aUnitsonorder, int  aReorderlevel, bool aDiscontinued)
            :this()
        {
            this.ProductID = aProductID;
            this.ProductName = aProductName;
            this.Supplier = aSupplier;
            this.Category = aCategory;
            this.QuantityPerUnit = aQuantityperunit;
            this.Unitprice = aUnitprice;
            this.Unitsinstock = aUnitsinstock;
            this.Unitsonorder = aUnitsonorder;
            this.Reorderlevel = aReorderlevel;
            this.Discontinued = aDiscontinued;
        }
        public Products(int aProductID, string aProductName, int aSupplier, int aCategory, string aQuantityperunit, double aUnitprice, int aUnitsinstock, int aUnitsonorder, int aReorderlevel)
            :this(aProductID,  aProductName,  aSupplier,  aCategory,  aQuantityperunit,  aUnitprice,  aUnitsinstock,  aUnitsonorder,  aReorderlevel, false)
        {

        }

         public Products(int aProductID, string aProductName, int aSupplier, int aCategory, string aQuantityperunit, double aUnitprice, int aUnitsinstock, int aUnitsonorder)
            :this(aProductID,  aProductName,  aSupplier,  aCategory,  aQuantityperunit,  aUnitprice,  aUnitsinstock,  aUnitsonorder, -1 , false)
         {

         }
        public Products(int aProductID, string aProductName, int aSupplier, int aCategory, string aQuantityperunit, double aUnitprice, int aUnitsinstock)
            :this(aProductID,  aProductName,  aSupplier,  aCategory,  aQuantityperunit,  aUnitprice,  aUnitsinstock,  -1, -1 , false)
         {

         }

         public Products(int aProductID, string aProductName, int aSupplier, int aCategory, string aQuantityperunit, double aUnitprice)
            :this(aProductID,  aProductName,  aSupplier,  aCategory,  aQuantityperunit,  aUnitprice,  -1 ,  -1, -1 , false)
        {

        }


         

        public Products(int aProductID, string aProductName, int aSupplier, int aCategory, string aQuantityperunit)
            : this(aProductID, aProductName, aSupplier, aCategory, aQuantityperunit, -1, -1, -1, -1, false)
        {

        }

        public Products(int aProductID, string aProductName, int aSupplier, int aCategory)
            : this(aProductID, aProductName, aSupplier, aCategory, "n/a", -1, -1, -1, -1, false)
        {


        }

        public Products(int aProductID, string aProductName, int aSupplier)
            : this(aProductID, aProductName, aSupplier, -1, "n/a", -1, -1, -1, -1, false)
        {


        }

        public Products(int aProductID, string aProductName)
            : this(aProductID, aProductName, -1, -1, "n/a", -1, -1, -1, -1, false)
        {


        }

        public Products(int aProductID)
            : this(aProductID, "na", -1, -1, "n/a", -1, -1, -1, -1, false)
        {


        }
    // overriding the tostring and display
        public override string ToString()
        {
            string aStringofproducts = " ";
            aStringofproducts = " Products ID = " + ProductID +"/n";
            aStringofproducts = " Product Name = " + ProductName +"/n";
            aStringofproducts = " Supplier = " + Supplier + "/n";
            aStringofproducts = " Category = " + Category + "/n";
            aStringofproducts = " Quantity Per Unit = " + QuantityPerUnit + "/n";
            aStringofproducts = " Unit Price = " + Unitprice + "/n";
            aStringofproducts = " Units in Stock = " + Unitsinstock + "/n";
            aStringofproducts = " Units on order = " + Unitsonorder + "/n";
            aStringofproducts = " Reorder level = " + Reorderlevel + "/n";
            aStringofproducts = " Discontinued = " + Discontinued.ToString() + "/n";
            return ToString();
        }

        public string Display()
        {
            string aStringofproducts = " ";
            aStringofproducts = " Products ID = " + ProductID + "<br />";
            aStringofproducts = " Product Name = " + ProductName + "<br />";
            aStringofproducts = " Supplier = " + Supplier + "<br />";
            aStringofproducts = " Category = " + Category + "<br />";
            aStringofproducts = " Quantity Per Unit = " + QuantityPerUnit + "<br />";
            aStringofproducts = " Unit Price = " + Unitprice + "<br />";
            aStringofproducts = " Units in Stock = " + Unitsinstock + "<br />";
            aStringofproducts = " Units on order = " + Unitsonorder + "<br />";
            aStringofproducts = " Reorder level = " + Reorderlevel + "<br />";
            aStringofproducts = " Discontinued = " + Discontinued.ToString() + "<br />";
            return Display();
        }
            
        
        

    }
}