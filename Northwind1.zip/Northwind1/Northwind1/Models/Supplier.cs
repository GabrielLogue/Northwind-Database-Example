﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Northwind1.Models
{
    public class Supplier
    {   //private data
        private int supplierID = -1;
        private string companyName= "n/a";
        private string contactName = "n/a";
        private string contactTitle = "n/a";
        private string address = "n/a";
        private string city = "n/a";
        private string region = "n/a";
        private string postalCode = "n/a";
        private string country = "n/a";
        private string phoneNumber = "n/a";
        private string fax = "n/a";
        private string homePage = "n/a";
        private static int numberofsuppliers = 0;
        //public getters and setters
        public int SupplierID
        {
            get
            {
                return this.supplierID;
            }
        }

        public string CompanyName
        {
            get
            {
                return this.companyName;
            }

            set
            {
                this.companyName = value;

            }

        }

        public string ContactName
        {
            get
            {
                return this.contactName;
            }

            set
            {
                this.ContactName = value;
            }
        }

        public string ContactTitle
        {
            get
            {
                return this.contactTitle;
            }

            set
            {
                this.contactTitle = value;
            }
        }

        public string Address
        {
            get
            {
                return this.address;
            }

            set
            {
                this.address = value;
            }
        }
        
        public string City
        {
            get
            {
                return this.city;
            }
            set
            {
                this.city = value;
            }
        }

        public string Region
        {
            get
            {
                return this.region;
            }

            set
            {
                
                    this.region = value;
              
                    
                        
            }
        }

        public string PostalCode
        {
            get
            {
                return this.postalCode;
            }
            set
            {
                this.postalCode = value;
            }
        }

        public string Country
        {
            get
            {
                return this.country;
            }

            set
            {
                this.country = value;
            }
        }

        public string PhoneNumber
        {
            get
            {
                return this.phoneNumber;
            }

            set
            {
                this.phoneNumber = value;
            }
        }

        public string Fax
        {
            get
            {
                return this.fax;
            }

            set
            {
                this.fax = value;
            }
        }

        public string HomePage
        {
            get
            {
                return this.homePage;
            }

            set
            {
                this.homePage = value;
            }
        }
        //Constructors and chained constructors
        public Supplier ()
        {
            Supplier.numberofsuppliers = Supplier.numberofsuppliers + 1;
        }

        public Supplier (int aSupplierID, string aCompanyName, string aContactName, string aContactTitle, string aAddress, string aCity, string aRegion, string aPostalCode, string aCountry, string aPhoneNumber, string aFax, string aHomePage) :this()
        {
            supplierID = aSupplierID;
            companyName = aCompanyName;
            contactName = aContactName;
            contactTitle = aContactTitle;
            address = aAddress;
            city = aCity;
            region = aRegion;
            postalCode = aPostalCode;
            country = aCountry;
            phoneNumber = aPhoneNumber;
            fax = aFax;
            homePage = aHomePage;
        }

        public Supplier(int aSupplierID, string aCompanyName, string aContactName, string aContactTitle, string aAddress, string aCity, string aRegion, string aPostalCode, string aCountry, string aPhoneNumber, string aFax)
            :this(aSupplierID, aCompanyName, aContactName, aContactTitle, aAddress, aCity, aRegion, aPostalCode, aCountry, aPhoneNumber, aFax, "na")
        {

        }

        public Supplier(int aSupplierID, string aCompanyName, string aContactName, string aContactTitle, string aAddress, string aCity, string aRegion, string aPostalCode, String aCountry, string aPhoneNumber )
            : this(aSupplierID, aCompanyName, aContactName, aContactTitle, aAddress, aCity, aRegion, aPostalCode, aCountry, aPhoneNumber, "na", "na")

        {

        }

        public Supplier(int aSupplierID, string aCompanyName,string aContactName, string aContactTitle, string aAddress, string aCity, string aRegion, string aPostalCode, string aCountry) 
            : this(aSupplierID, aCompanyName, aContactName, aContactTitle, aAddress, aCity, aRegion, aPostalCode, aCountry, "na","na","na")
        {

        }
        
        public Supplier(int aSupplierId, string aCompanyName, string aContactName, string aContactTitle, string aAddress, string aCity, string aRegion, string aPostalCode)
            : this(aSupplierId, aCompanyName, aContactName, aContactTitle, aAddress, aCity,  aRegion, "na","na","na","na")
        {

        }

        public Supplier(int aSupplierID, string aCompanyName, string aContactName, string aContactTitle, string aAddress, string aCity, string aRegion) 
            : this(aSupplierID, aCompanyName, aContactName, aContactTitle, aAddress, aCity, aRegion, "na","na","na","na","na")
        {

        }

        public Supplier(int aSupplierID, string aCompanyName, string aContactName, string aContactTitle, string aAddress, string aCity) 
            : this(aSupplierID, aCompanyName, aContactName, aContactTitle, aAddress, aCity,"na","na","na","na","na","na")
        {

        }

        public Supplier (int aSupplierID, string aCompanyName, string aContactName ,string aContactTitle, string aAddress) 
            : this(aSupplierID, aCompanyName, aContactName, aContactTitle, aAddress, "na","na","na","na","na","na","na")
        {

        }

        public Supplier (int aSupplierID, string aCompanyName, string aContactName, string aContactTitle): 
            this(aSupplierID,aCompanyName, aContactTitle, "na","na","na","na","na","na","na","na")
        {

        }

        public Supplier(int aSupplierID, string aCompanyName, string aContactName)
            :this(aSupplierID, aCompanyName, aContactName, "na", "na","na","na","na","na","na","na", "na")
        {

        }

        public Supplier(int aSupplierID, string aCompanyName)
                :this (aSupplierID, aCompanyName,"na","na","na","na","na","na","na","na","na","na")
        {

        }

        public Supplier(int aSupplierID)
            :this(aSupplierID, "na","na","na","na","na","na","na","na","na","na","na")
        {

        }
        // overriding the ToString and Display
        public override string ToString()
        {
            string aString = " ";
            aString = aString + " Supplier ID = " + SupplierID + "/n";
            aString = aString + " Company Name = " + CompanyName + "/n";
            aString = aString + " Contact Name = " + ContactName + "/n";
            aString = aString + " Contact Title =" + ContactTitle + "/n";
            aString = aString + " Address = " + Address + "/n";
            aString = aString + " City = " + City + "/n";
            aString = aString + " Region = " + Region + "/n";
            aString = aString + " Postal Code = " + PostalCode + "/n";
            aString = aString + " Country = " + Country + "/n";
            aString = aString + " Phone Number = " + PhoneNumber + "/n";
            aString = aString + " Fax Number = " + Fax + "/n";
            aString = aString + " HomePage " + HomePage + "/n";
            return aString;
        }

        public string Display()
        {
            string aString = " ";
            aString = aString + " Supplier ID = " + SupplierID + "<br />";
            aString = aString + " Company Name = " + CompanyName + "<br />";
            aString = aString + " Contact Name " + ContactName + "<br />";
            aString = aString + " Contact Title =" + ContactTitle + "<br />";
            aString = aString + " Address = " + Address + "<br />";
            aString = aString + " City = " + City + "<br />";
            aString = aString + " Region = " + Region + "<br />";
            aString = aString + " Postal Code = " + PostalCode + "<br />";
            aString = aString + " Country = " + Country + "<br />";
            aString = aString + " Phone Number = " + PhoneNumber + "<br />";
            aString = aString + " Fax Number = " + Fax + "<br />";
            aString = aString + " HomePage " + HomePage + "<br />";
            return aString;
        }



    }
}