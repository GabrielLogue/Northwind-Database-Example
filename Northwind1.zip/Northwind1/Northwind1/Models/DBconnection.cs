﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.OleDb;
using System.Data.Odbc;

namespace Northwind1.Models
{
    public sealed class DBconnection
    {
        //one connection for every class

        private static DBconnection instance = null;


        private DBconnection() { }

        public static DBconnection Instance
        {
            get
            {
              if(instance == null)
            {
                instance = new DBconnection();
            }
                return instance;
            }
           
        }
        // create a list of categories
        private List<Category> aListofCategories = new List<Category>();
        //create a list of products
        private List<Products> aListofProducts = new List<Products>();
        //create a list of suppliers
        private List<Supplier> aListofSuppliers = new List<Supplier>();

        //create a method to get categories and put them in the list of categories
        public List<Category> GetCategories(){
            OleDbConnection aConnection = new OleDbConnection();
            //this is the sql statement used to get the data from the datahae
            string aSQL = "SELECT CategoryID, CategoryName, Description FROM Categories;";
            //use this connection string to find the database file with the microsoft Jet engine for the OleDb library
            aConnection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Owner\Downloads\Northwind.mdb;";
            //open the connection to the database
            aConnection.Open();
            //create a Command object;
            OleDbCommand aCommand = aConnection.CreateCommand();
            //assign the Command text property of the command objet with the sql statement created earilier
            aCommand.CommandText = aSQL;
            //use this to start the OleDb reader
            OleDbDataReader aReader = aCommand.ExecuteReader();

            //read the data and store it in a list
            while(aReader.Read())
            {
                //cast the data from the categoryID field in the database into an int value
                int aCategoryID = (int)aReader["CategoryID"];
                //cast the data from the CategoryName field in the database into a string value
                string aCategoryName = (string)aReader["CategoryName"];
                //cast the data from the Desctiption field in the database into a string value
                string aDescription = (string)aReader["Description"];
                //create a Category object with parameters that have the values from the database 
                Category aCategory = new Category(aCategoryID, aCategoryName, aDescription);
                //add that category object into the category List
                aListofCategories.Add(aCategory);
            }
            // return the list of categories
            return aListofCategories;


        }

        //create a method to get Products and put them in the list of Products
        public List<Products> GetProducts()
        {
            OleDbConnection aConnection = new OleDbConnection();
            //create a sql string
            string aSql = "SELECT ProductID, ProductName, SupplierID, CategoryID, QuantityPerUnit, UnitPrice, Unitsinstock, Unitsonorder, ReorderLevel, Discontinued FROM Products;";
            //this is the connection string used by the microsoft jet engine for the oledb engine
           aConnection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Owner\Downloads\Northwind.mdb;";
           //Open the connection to the database to get data
           aConnection.Open();
            //create a command
           OleDbCommand aCommand = aConnection.CreateCommand();
            //assign the command the sql statement
            aCommand.CommandText = aSql;
            //start the oledb reader
            OleDbDataReader aReader = aCommand.ExecuteReader();
            while(aReader.Read())
            {
                //take the productId and cast it into an int variable
              int aProductID = (int)aReader["ProductID"];
                //take the productname and put it into a string variable
              string aProductName = (string)aReader["ProductName"];
                  //take the supplierid and put it into an int variable
              int aSupplier = (int)aReader["SupplierID"];
                //take the categoryid and put it into an int variable
              int aCategory = (int)aReader["CategoryID"];
                //take the quantityperunit and put it into a string variable
              string aQuantityperunit = (string)aReader["QuantityPerUnit"];
               //take the unitprice and cast it into a double decimal value
              double aUnitprice  = (double)(decimal)aReader["UnitPrice"];
                //take the unitsinstock and cast it into a short int variable;
              int aUnitsinstock = (int)(short)aReader["UnitsInStock"];
                //take the unitsonorder and cast it into a short int variable
              int aUnitsonorder = (int)(short)aReader["UnitsOnOrder"];
                //take the reorderlevel and cast it into a short int variable
              int aReorderlevel = (int)(short)aReader["ReorderLevel"];
                // take the discontinued and cast it into a bool variable
              bool aDiscontinued = (bool)aReader["Discontinued"];

                //create a Product from the data obtained from the database
                Products aProduct = new Products(aProductID, aProductName, aSupplier, aCategory, aQuantityperunit, aUnitprice, aUnitsinstock, aUnitsonorder, aReorderlevel, aDiscontinued);
                //take the object and put it into the products list
                aListofProducts.Add(aProduct);

            }
            //return the list of products
            return aListofProducts;
            
        }

        //create a method that creates supplier objects from data obtained from the database
        public List<Supplier> GetSupplier()
        {
            OleDbConnection aConnection = new OleDbConnection();
            //create a sql statement
            string aSql = "SELECT SupplierID, CompanyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax, HomePage FROM Suppliers;";
            // use the connection string to connect to the database
            aConnection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Owner\Downloads\Northwind.mdb;";
            //open the connection to obtain data
            aConnection.Open();
            //create a command class
            OleDbCommand aCommand = aConnection.CreateCommand();
            //assign the command class text property the sql statement
            aCommand.CommandText = aSql;
            //create the datareader
            OleDbDataReader aReader = aCommand.ExecuteReader();
            
            while(aReader.Read())
            {   //take the supplierID and cast it into an int variable
                int aSupplierID = (int)aReader["SupplierID"];
                //take the CompanyName and cast it into a string variable
                string aCompanyName = (string)aReader["CompanyName"];
                //take the ContactName and cast it into a string variable
                string aContactName = (string)aReader["ContactName"];
                //take the ContactTitle and cast it into a string variable
                string aContactTitle = (string)aReader["ContactTitle"];
                //take the address and cast it into a string variable
                string aAddress = (string)aReader["Address"];
                //take the city and cast it into a string variable
                string aCity = (string)aReader["City"];
                //take the region and cast it into a string variable if it isn't null, if it is null, display nothing
                string aRegion = (aReader["Region"] ?? "").ToString();
                //take the postalcode  and cast it into a string variable
                string aPostalCode = (string)aReader["PostalCode"];
                //take the country and cast it into a string variable
                string aCountry = (string)aReader["Country"];
                //take the phone and cast it into a string variable if it isn't null, if it is null, display nothing
                string aPhoneNumber = (aReader["Phone"] ?? "").ToString(); 
                // take the fax and cast it into a string variable if it isn't null, if it is null, display nothing
                string aFax = (aReader["Fax"] ?? "").ToString();
                // take the homepage and cast it into a string variable if it isn't null, if it is null, display nothing
                string aHomePage = (aReader["HomePage"] ?? "").ToString();
               
                
                //create a supplier object and give it the parameters that have the data values from the database
                Supplier aSupplier= new Supplier(aSupplierID, aCompanyName, aContactName, aContactTitle, aAddress, aCity,  aRegion, aPostalCode, aCountry, aFax, aHomePage);
                //take the supplier object and put it into the supplier list
                aListofSuppliers.Add(aSupplier);
            }
            //return the list of suppliers
            return aListofSuppliers;
        }
    

        


    }
}
           